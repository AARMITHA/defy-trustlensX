from web3 import Web3
import os
from dotenv import load_dotenv

load_dotenv()

RPC = "https://api-mezame.shardeum.org"
PRIVATE_KEY = os.getenv("SHARDEUM_PRIVATE_KEY")
WALLET = Web3.to_checksum_address(os.getenv("SHARDEUM_WALLET"))

CONTRACT_ADDRESS = Web3.to_checksum_address(
    "0xF0e44DB9921a7bFD58DD975dbfE231e77E57D21f"
)

ABI = [
  {
    "inputs": [
      {"internalType": "string", "name": "nftId", "type": "string"},
      {"internalType": "uint256", "name": "score", "type": "uint256"},
      {"internalType": "string", "name": "risk", "type": "string"}
    ],
    "name": "setTrust",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
]

w3 = Web3(Web3.HTTPProvider(RPC))
contract = w3.eth.contract(address=CONTRACT_ADDRESS, abi=ABI)

def store_on_chain(nft_id, score, risk):
    nonce = w3.eth.get_transaction_count(WALLET)
    tx = contract.functions.setTrust(
        nft_id,
        int(score),
        risk
    ).build_transaction({
        "from": WALLET,
        "nonce": nonce,
        "gas": 300000,
        "gasPrice": w3.to_wei("1", "gwei"),
        "chainId": 8119
    })

    signed = w3.eth.account.sign_transaction(tx, PRIVATE_KEY)
    tx_hash = w3.eth.send_raw_transaction(signed.rawTransaction)
    return tx_hash.hex()
