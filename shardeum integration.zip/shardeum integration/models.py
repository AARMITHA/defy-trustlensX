from pydantic import BaseModel
from typing import List

class Trade(BaseModel):
    buyer: str
    seller: str
    price: float
    timestamp: int

class NFTRequest(BaseModel):
    contract: str
    token_id: str
