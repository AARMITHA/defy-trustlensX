import requests

def fetch_trades(contract, token_id):
    url = f"https://restapi.nftscan.com/api/v2/assets/contract/{contract}/{token_id}/transactions"
    r = requests.get(url, timeout=10).json()

    trades = []

    for tx in r.get("data", []):
        trades.append({
            "buyer": tx["to"],
            "seller": tx["from"],
            "price": float(tx.get("price", 0)),
            "timestamp": int(tx["timestamp"])
        })

    return trades
