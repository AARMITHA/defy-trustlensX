from collections import Counter

def volume_agent(trades):
    if len(trades) == 0:
        return "No Data", 0.0

    buyers = [t["buyer"] for t in trades]
    counts = Counter(buyers)

    concentration = max(counts.values()) / len(trades)

    if concentration > 0.6:
        return "Suspicious", concentration
    else:
        return "Trustworthy", concentration


def wallet_agent(trades):
    if len(trades) == 0:
        return "No Data", 0

    wallets = set()
    for t in trades:
        wallets.add(t["buyer"])
        wallets.add(t["seller"])

    if len(wallets) < 5:
        return "Suspicious", len(wallets)
    return "Trustworthy", len(wallets)


def price_agent(trades):
    prices = [t["price"] for t in trades if t["price"] > 0]

    if len(prices) < 2:
        return "No Data", 0

    vol = (max(prices) - min(prices)) / max(prices)

    if vol > 0.5:
        return "Suspicious", vol
    return "Trustworthy", vol
def manipulation_agent(price_volatility, wallet_diversity, volume_concentration):
    score = 0

    if price_volatility > 0.5:
        score += 1
    if wallet_diversity < 5:
        score += 1
    if volume_concentration > 0.6:
        score += 1

    if score >= 2:
        return "High Risk"
    elif score == 1:
        return "Medium Risk"
    else:
        return "Low Risk"
