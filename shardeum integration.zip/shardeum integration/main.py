from fastapi import FastAPI
from models import NFTRequest
from nft_data import fetch_trades
from agents import *
from rules import compute_trust
from shardeum import store_on_chain

app = FastAPI(title="TrustLens X")

@app.post("/analyze")
def analyze_nft(nft: NFTRequest):
    trades = fetch_trades(nft.contract, nft.token_id)

    p_verdict, pv = price_agent(trades)
    w_verdict, wd = wallet_agent(trades)
    v_verdict, vc = volume_agent(trades)
    m_verdict = manipulation_agent(pv, wd, vc)

    trust, risk = compute_trust(pv, wd, vc)

    nft_id = f"{nft.contract}:{nft.token_id}"
    tx_hash = store_on_chain(nft_id, trust, risk)

    prices = [t["price"] for t in trades if t["price"] > 0]

    return {
        "nft": nft.dict(),
        "trust_score": trust,
        "risk_level": risk,
        "price_band": {
            "min": min(prices) if prices else 0,
            "max": max(prices) if prices else 0,
            "currency": "ETH"
        },
        "agents": [
            {"name":"Price Agent","verdict":p_verdict},
            {"name":"Wallet Agent","verdict":w_verdict},
            {"name":"Volume Agent","verdict":v_verdict},
            {"name":"Manipulation Agent","verdict":m_verdict}
        ],
        "on_chain_tx": tx_hash
    }

