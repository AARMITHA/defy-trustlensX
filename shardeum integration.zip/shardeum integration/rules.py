def compute_trust(pv, wd, vc):
    risk = 0
    if pv > 0.15: risk += 30
    if wd != 0 and wd < 0.4: risk += 35
    if vc > 0.5: risk += 35

    trust = max(0, 100 - risk)

    if trust >= 70:
        level = "LOW"
    elif trust >= 40:
        level = "MEDIUM"
    else:
        level = "HIGH"

    return trust, level
